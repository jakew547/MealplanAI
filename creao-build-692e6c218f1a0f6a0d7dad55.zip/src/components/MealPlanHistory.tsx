import { type DietaryProfile, type MealPlanResponse } from "@/hooks/use-meal-planner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Calendar, Trash2, Eye } from "lucide-react";

interface SavedMealPlan {
	id: string;
	profile: DietaryProfile;
	plan: MealPlanResponse;
	createdAt: string;
}

interface MealPlanHistoryProps {
	plans: SavedMealPlan[];
	onLoadPlan: (plan: SavedMealPlan) => void;
	onDeletePlan: (id: string) => void;
}

export function MealPlanHistory({ plans, onLoadPlan, onDeletePlan }: MealPlanHistoryProps) {
	const formatDate = (dateString: string) => {
		const date = new Date(dateString);
		return date.toLocaleDateString("en-US", {
			month: "short",
			day: "numeric",
			year: "numeric",
			hour: "2-digit",
			minute: "2-digit",
		});
	};

	if (plans.length === 0) {
		return (
			<Card>
				<CardContent className="p-12 text-center">
					<Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
					<h3 className="text-lg font-semibold text-gray-700 mb-2">No Meal Plans Yet</h3>
					<p className="text-gray-500">
						Your generated meal plans will appear here. Create your first plan to get started!
					</p>
				</CardContent>
			</Card>
		);
	}

	return (
		<Card>
			<CardHeader>
				<CardTitle>Meal Plan History</CardTitle>
				<CardDescription>View and reuse your previously generated meal plans</CardDescription>
			</CardHeader>
			<CardContent>
				<ScrollArea className="h-[600px] pr-4">
					<div className="space-y-4">
						{plans.map((savedPlan) => (
							<Card key={savedPlan.id} className="hover:shadow-md transition-shadow">
								<CardContent className="p-4">
									<div className="flex items-start justify-between gap-4">
										<div className="flex-1">
											<div className="flex items-center gap-2 mb-2">
												<Calendar className="w-4 h-4 text-gray-500" />
												<span className="text-sm text-gray-600">{formatDate(savedPlan.createdAt)}</span>
											</div>
											<div className="space-y-2">
												{savedPlan.profile.restrictions && savedPlan.profile.restrictions.length > 0 && (
													<div>
														<p className="text-sm font-semibold text-gray-700">Dietary Restrictions:</p>
														<div className="flex flex-wrap gap-1 mt-1">
															{savedPlan.profile.restrictions.map((restriction) => (
																<Badge key={restriction} variant="outline" className="text-xs">
																	{restriction}
																</Badge>
															))}
														</div>
													</div>
												)}
												{savedPlan.profile.allergies && savedPlan.profile.allergies.length > 0 && (
													<div>
														<p className="text-sm font-semibold text-gray-700">Allergies:</p>
														<div className="flex flex-wrap gap-1 mt-1">
															{savedPlan.profile.allergies.map((allergy) => (
																<Badge key={allergy} variant="destructive" className="text-xs">
																	{allergy}
																</Badge>
															))}
														</div>
													</div>
												)}
												{savedPlan.profile.medicalConditions && savedPlan.profile.medicalConditions.length > 0 && (
													<div>
														<p className="text-sm font-semibold text-gray-700">Medical Conditions:</p>
														<p className="text-sm text-gray-600">{savedPlan.profile.medicalConditions.join(", ")}</p>
													</div>
												)}
												<div className="pt-2">
													<p className="text-sm text-gray-600">
														{savedPlan.plan.weeklyPlan.length} days •{" "}
														{savedPlan.plan.weeklyPlan.reduce((acc, day) => acc + day.meals.length, 0)} meals •{" "}
														{savedPlan.plan.shoppingList.length} items in shopping list
													</p>
												</div>
											</div>
										</div>
										<div className="flex gap-2">
											<Button variant="outline" size="sm" onClick={() => onLoadPlan(savedPlan)}>
												<Eye className="w-4 h-4 mr-1" />
												View
											</Button>
											<Button
												variant="ghost"
												size="sm"
												onClick={() => {
													if (confirm("Are you sure you want to delete this meal plan?")) {
														onDeletePlan(savedPlan.id);
													}
												}}
											>
												<Trash2 className="w-4 h-4 text-red-500" />
											</Button>
										</div>
									</div>
								</CardContent>
							</Card>
						))}
					</div>
				</ScrollArea>
			</CardContent>
		</Card>
	);
}
