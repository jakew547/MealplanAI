import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Check, Sparkles, CreditCard } from "lucide-react";
import { getStripe, PRICING, createCheckoutSession } from "@/lib/stripe";

interface CheckoutDialogProps {
	open: boolean;
	onClose: () => void;
	userEmail: string;
	onSuccess: (interval: "month" | "year") => void;
}

export function CheckoutDialog({ open, onClose, userEmail, onSuccess }: CheckoutDialogProps) {
	const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("yearly");
	const [isProcessing, setIsProcessing] = useState(false);
	const [error, setError] = useState("");

	const handleCheckout = async () => {
		setIsProcessing(true);
		setError("");

		try {
			// NOTE: In production, this would call your backend API
			// Your backend should create a Stripe Checkout Session and return the session ID
			// Then you would redirect to Stripe Checkout using window.location.href

			// Example production flow:
			// const plan = PRICING[selectedPlan];
			// const session = await createCheckoutSession({
			//   priceId: plan.priceId,
			//   email: userEmail,
			//   successUrl: `${window.location.origin}?success=true`,
			//   cancelUrl: `${window.location.origin}?canceled=true`,
			// });
			// window.location.href = session.url; // Redirect to Stripe Checkout

			// For demo purposes, simulate successful payment
			console.log("Simulating successful payment for demo");
			await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
			onSuccess(selectedPlan === "monthly" ? "month" : "year");
			onClose();
		} catch (err) {
			setError(err instanceof Error ? err.message : "An error occurred during checkout");
			setIsProcessing(false);
		}
	};

	return (
		<Dialog open={open} onOpenChange={onClose}>
			<DialogContent className="sm:max-w-2xl">
				<DialogHeader>
					<DialogTitle className="text-2xl flex items-center gap-2">
						<Sparkles className="w-6 h-6 text-purple-600" />
						Choose Your Premium Plan
					</DialogTitle>
					<DialogDescription>Select the plan that works best for you</DialogDescription>
				</DialogHeader>

				<div className="grid md:grid-cols-2 gap-4 mt-4">
					{/* Monthly Plan */}
					<Card
						className={`cursor-pointer transition-all ${
							selectedPlan === "monthly"
								? "border-purple-500 border-2 shadow-lg"
								: "border-gray-200 hover:border-purple-300"
						}`}
						onClick={() => setSelectedPlan("monthly")}
					>
						<CardHeader>
							<CardTitle className="flex items-center justify-between">
								Monthly
								{selectedPlan === "monthly" && (
									<Check className="w-5 h-5 text-purple-600" />
								)}
							</CardTitle>
							<CardDescription>Billed monthly</CardDescription>
						</CardHeader>
						<CardContent>
							<div className="mb-4">
								<p className="text-4xl font-bold text-purple-900">$4.99</p>
								<p className="text-sm text-gray-600">per month</p>
							</div>
							<div className="space-y-2">
								<div className="flex items-center gap-2 text-sm">
									<Check className="w-4 h-4 text-green-600" />
									<span>All premium features</span>
								</div>
								<div className="flex items-center gap-2 text-sm">
									<Check className="w-4 h-4 text-green-600" />
									<span>Cancel anytime</span>
								</div>
								<div className="flex items-center gap-2 text-sm">
									<Check className="w-4 h-4 text-green-600" />
									<span>Flexible billing</span>
								</div>
							</div>
						</CardContent>
					</Card>

					{/* Yearly Plan */}
					<Card
						className={`cursor-pointer transition-all relative ${
							selectedPlan === "yearly"
								? "border-purple-500 border-2 shadow-lg"
								: "border-gray-200 hover:border-purple-300"
						}`}
						onClick={() => setSelectedPlan("yearly")}
					>
						<Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-purple-500 to-pink-500">
							Save $10
						</Badge>
						<CardHeader>
							<CardTitle className="flex items-center justify-between">
								Yearly
								{selectedPlan === "yearly" && (
									<Check className="w-5 h-5 text-purple-600" />
								)}
							</CardTitle>
							<CardDescription>Billed annually</CardDescription>
						</CardHeader>
						<CardContent>
							<div className="mb-4">
								<p className="text-4xl font-bold text-purple-900">$50</p>
								<p className="text-sm text-gray-600">per year</p>
								<p className="text-xs text-green-600 font-semibold mt-1">
									Save $10 compared to monthly
								</p>
							</div>
							<div className="space-y-2">
								<div className="flex items-center gap-2 text-sm">
									<Check className="w-4 h-4 text-green-600" />
									<span>All premium features</span>
								</div>
								<div className="flex items-center gap-2 text-sm">
									<Check className="w-4 h-4 text-green-600" />
									<span>Best value</span>
								</div>
								<div className="flex items-center gap-2 text-sm">
									<Check className="w-4 h-4 text-green-600" />
									<span>2 months free</span>
								</div>
							</div>
						</CardContent>
					</Card>
				</div>

				{/* Premium Features */}
				<div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
					<h4 className="font-semibold text-purple-900 mb-3">Premium Features Include:</h4>
					<div className="grid md:grid-cols-2 gap-2">
						<div className="flex items-center gap-2 text-sm text-purple-800">
							<Check className="w-4 h-4 text-green-600 flex-shrink-0" />
							<span>Unlimited AI-generated meal plans</span>
						</div>
						<div className="flex items-center gap-2 text-sm text-purple-800">
							<Check className="w-4 h-4 text-green-600 flex-shrink-0" />
							<span>Export grocery lists & meal plans</span>
						</div>
						<div className="flex items-center gap-2 text-sm text-purple-800">
							<Check className="w-4 h-4 text-green-600 flex-shrink-0" />
							<span>Regenerate individual meals</span>
						</div>
						<div className="flex items-center gap-2 text-sm text-purple-800">
							<Check className="w-4 h-4 text-green-600 flex-shrink-0" />
							<span>Access to meal plan history</span>
						</div>
						<div className="flex items-center gap-2 text-sm text-purple-800">
							<Check className="w-4 h-4 text-green-600 flex-shrink-0" />
							<span>Custom dietary preferences</span>
						</div>
						<div className="flex items-center gap-2 text-sm text-purple-800">
							<Check className="w-4 h-4 text-green-600 flex-shrink-0" />
							<span>Priority customer support</span>
						</div>
					</div>
				</div>

				{error && (
					<Alert variant="destructive">
						<AlertDescription>{error}</AlertDescription>
					</Alert>
				)}

				<div className="flex gap-3 mt-4">
					<Button variant="outline" onClick={onClose} className="flex-1" disabled={isProcessing}>
						Cancel
					</Button>
					<Button
						onClick={handleCheckout}
						className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
						disabled={isProcessing}
					>
						{isProcessing ? (
							<>
								<Loader2 className="w-4 h-4 mr-2 animate-spin" />
								Processing...
							</>
						) : (
							<>
								<CreditCard className="w-4 h-4 mr-2" />
								Continue to Payment
							</>
						)}
					</Button>
				</div>

				<p className="text-xs text-center text-gray-500 mt-2">
					Secure payment powered by Stripe. Cancel anytime.
				</p>
			</DialogContent>
		</Dialog>
	);
}
