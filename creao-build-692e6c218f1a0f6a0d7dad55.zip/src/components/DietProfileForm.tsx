import { useState } from "react";
import { type DietaryProfile } from "@/hooks/use-meal-planner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Plus, X, AlertCircle } from "lucide-react";

interface DietProfileFormProps {
	onGeneratePlan: (
		profile: DietaryProfile,
		options: {
			days: number;
			caloriesPerDay?: number;
			mealsPerDay: number;
			additionalInstructions?: string;
		}
	) => void;
	isGenerating: boolean;
	error?: string;
}

const COMMON_RESTRICTIONS = [
	"AIP",
	"low-FODMAP",
	"gluten-free",
	"dairy-free",
	"nut-free",
	"shellfish-free",
	"egg-free",
	"soy-free",
	"vegan",
	"vegetarian",
	"keto",
	"paleo",
];

export function DietProfileForm({ onGeneratePlan, isGenerating, error }: DietProfileFormProps) {
	const [restrictions, setRestrictions] = useState<string[]>([]);
	const [customRestriction, setCustomRestriction] = useState("");
	const [allergies, setAllergies] = useState<string[]>([]);
	const [allergyInput, setAllergyInput] = useState("");
	const [intolerances, setIntolerances] = useState<string[]>([]);
	const [intoleranceInput, setIntoleranceInput] = useState("");
	const [medicalConditions, setMedicalConditions] = useState<string[]>([]);
	const [medicalInput, setMedicalInput] = useState("");
	const [preferences, setPreferences] = useState<string[]>([]);
	const [preferenceInput, setPreferenceInput] = useState("");
	const [days, setDays] = useState("7");
	const [caloriesPerDay, setCaloriesPerDay] = useState("");
	const [mealsPerDay, setMealsPerDay] = useState("3");
	const [additionalInstructions, setAdditionalInstructions] = useState("");

	const addRestriction = (restriction: string) => {
		if (restriction && !restrictions.includes(restriction)) {
			setRestrictions([...restrictions, restriction]);
		}
		setCustomRestriction("");
	};

	const removeRestriction = (restriction: string) => {
		setRestrictions(restrictions.filter((r) => r !== restriction));
	};

	const addAllergy = () => {
		if (allergyInput.trim() && !allergies.includes(allergyInput.trim())) {
			setAllergies([...allergies, allergyInput.trim()]);
			setAllergyInput("");
		}
	};

	const removeAllergy = (allergy: string) => {
		setAllergies(allergies.filter((a) => a !== allergy));
	};

	const addIntolerance = () => {
		if (intoleranceInput.trim() && !intolerances.includes(intoleranceInput.trim())) {
			setIntolerances([...intolerances, intoleranceInput.trim()]);
			setIntoleranceInput("");
		}
	};

	const removeIntolerance = (intolerance: string) => {
		setIntolerances(intolerances.filter((i) => i !== intolerance));
	};

	const addMedicalCondition = () => {
		if (medicalInput.trim() && !medicalConditions.includes(medicalInput.trim())) {
			setMedicalConditions([...medicalConditions, medicalInput.trim()]);
			setMedicalInput("");
		}
	};

	const removeMedicalCondition = (condition: string) => {
		setMedicalConditions(medicalConditions.filter((c) => c !== condition));
	};

	const addPreference = () => {
		if (preferenceInput.trim() && !preferences.includes(preferenceInput.trim())) {
			setPreferences([...preferences, preferenceInput.trim()]);
			setPreferenceInput("");
		}
	};

	const removePreference = (preference: string) => {
		setPreferences(preferences.filter((p) => p !== preference));
	};

	const handleSubmit = (e: React.FormEvent) => {
		e.preventDefault();

		if (restrictions.length === 0) {
			return;
		}

		const profile: DietaryProfile = {
			restrictions,
			allergies: allergies.length > 0 ? allergies : undefined,
			intolerances: intolerances.length > 0 ? intolerances : undefined,
			medicalConditions: medicalConditions.length > 0 ? medicalConditions : undefined,
			preferences: preferences.length > 0 ? preferences : undefined,
		};

		onGeneratePlan(profile, {
			days: parseInt(days),
			caloriesPerDay: caloriesPerDay ? parseInt(caloriesPerDay) : undefined,
			mealsPerDay: parseInt(mealsPerDay),
			additionalInstructions: additionalInstructions.trim() || undefined,
		});
	};

	return (
		<Card>
			<CardHeader>
				<CardTitle>Create Your Dietary Profile</CardTitle>
				<CardDescription>
					Enter your dietary restrictions, allergies, and preferences to generate a personalized meal plan
				</CardDescription>
			</CardHeader>
			<CardContent>
				<form onSubmit={handleSubmit} className="space-y-6">
					{/* Dietary Restrictions */}
					<div className="space-y-3">
						<Label className="text-base font-semibold">
							Dietary Restrictions <span className="text-red-500">*</span>
						</Label>
						<div className="flex flex-wrap gap-2">
							{COMMON_RESTRICTIONS.map((restriction) => (
								<Badge
									key={restriction}
									variant={restrictions.includes(restriction) ? "default" : "outline"}
									className="cursor-pointer"
									onClick={() => {
										if (restrictions.includes(restriction)) {
											removeRestriction(restriction);
										} else {
											addRestriction(restriction);
										}
									}}
								>
									{restriction}
									{restrictions.includes(restriction) && <X className="ml-1 w-3 h-3" />}
								</Badge>
							))}
						</div>
						<div className="flex gap-2">
							<Input
								placeholder="Add custom restriction..."
								value={customRestriction}
								onChange={(e) => setCustomRestriction(e.target.value)}
								onKeyDown={(e) => {
									if (e.key === "Enter") {
										e.preventDefault();
										addRestriction(customRestriction);
									}
								}}
							/>
							<Button
								type="button"
								variant="outline"
								size="icon"
								onClick={() => addRestriction(customRestriction)}
							>
								<Plus className="w-4 h-4" />
							</Button>
						</div>
					</div>

					{/* Allergies */}
					<div className="space-y-3">
						<Label className="text-base font-semibold">Allergies (Strict Exclusion)</Label>
						<div className="flex flex-wrap gap-2 min-h-[32px]">
							{allergies.map((allergy) => (
								<Badge key={allergy} variant="destructive">
									{allergy}
									<button
										type="button"
										onClick={() => removeAllergy(allergy)}
										className="ml-1 hover:bg-red-700 rounded-full"
									>
										<X className="w-3 h-3" />
									</button>
								</Badge>
							))}
						</div>
						<div className="flex gap-2">
							<Input
								placeholder="e.g., peanuts, shellfish, tree nuts..."
								value={allergyInput}
								onChange={(e) => setAllergyInput(e.target.value)}
								onKeyDown={(e) => {
									if (e.key === "Enter") {
										e.preventDefault();
										addAllergy();
									}
								}}
							/>
							<Button type="button" variant="outline" size="icon" onClick={addAllergy}>
								<Plus className="w-4 h-4" />
							</Button>
						</div>
					</div>

					{/* Intolerances */}
					<div className="space-y-3">
						<Label className="text-base font-semibold">Intolerances</Label>
						<div className="flex flex-wrap gap-2 min-h-[32px]">
							{intolerances.map((intolerance) => (
								<Badge key={intolerance} variant="secondary">
									{intolerance}
									<button
										type="button"
										onClick={() => removeIntolerance(intolerance)}
										className="ml-1 hover:bg-gray-400 rounded-full"
									>
										<X className="w-3 h-3" />
									</button>
								</Badge>
							))}
						</div>
						<div className="flex gap-2">
							<Input
								placeholder="e.g., lactose, gluten, fructose..."
								value={intoleranceInput}
								onChange={(e) => setIntoleranceInput(e.target.value)}
								onKeyDown={(e) => {
									if (e.key === "Enter") {
										e.preventDefault();
										addIntolerance();
									}
								}}
							/>
							<Button type="button" variant="outline" size="icon" onClick={addIntolerance}>
								<Plus className="w-4 h-4" />
							</Button>
						</div>
					</div>

					{/* Medical Conditions */}
					<div className="space-y-3">
						<Label className="text-base font-semibold">Medical Conditions</Label>
						<div className="flex flex-wrap gap-2 min-h-[32px]">
							{medicalConditions.map((condition) => (
								<Badge key={condition} variant="outline" className="border-blue-300 text-blue-700">
									{condition}
									<button
										type="button"
										onClick={() => removeMedicalCondition(condition)}
										className="ml-1 hover:bg-blue-100 rounded-full"
									>
										<X className="w-3 h-3" />
									</button>
								</Badge>
							))}
						</div>
						<div className="flex gap-2">
							<Input
								placeholder="e.g., Hashimoto's thyroiditis, IBS, Crohn's disease..."
								value={medicalInput}
								onChange={(e) => setMedicalInput(e.target.value)}
								onKeyDown={(e) => {
									if (e.key === "Enter") {
										e.preventDefault();
										addMedicalCondition();
									}
								}}
							/>
							<Button type="button" variant="outline" size="icon" onClick={addMedicalCondition}>
								<Plus className="w-4 h-4" />
							</Button>
						</div>
					</div>

					{/* Preferences */}
					<div className="space-y-3">
						<Label className="text-base font-semibold">Preferences</Label>
						<div className="flex flex-wrap gap-2 min-h-[32px]">
							{preferences.map((preference) => (
								<Badge key={preference} variant="outline" className="border-green-300 text-green-700">
									{preference}
									<button
										type="button"
										onClick={() => removePreference(preference)}
										className="ml-1 hover:bg-green-100 rounded-full"
									>
										<X className="w-3 h-3" />
									</button>
								</Badge>
							))}
						</div>
						<div className="flex gap-2">
							<Input
								placeholder="e.g., organic ingredients, minimal prep time, batch cooking..."
								value={preferenceInput}
								onChange={(e) => setPreferenceInput(e.target.value)}
								onKeyDown={(e) => {
									if (e.key === "Enter") {
										e.preventDefault();
										addPreference();
									}
								}}
							/>
							<Button type="button" variant="outline" size="icon" onClick={addPreference}>
								<Plus className="w-4 h-4" />
							</Button>
						</div>
					</div>

					{/* Meal Plan Options */}
					<div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
						<div className="space-y-2">
							<Label htmlFor="days">Number of Days</Label>
							<Select value={days} onValueChange={setDays}>
								<SelectTrigger id="days">
									<SelectValue />
								</SelectTrigger>
								<SelectContent>
									{[1, 2, 3, 4, 5, 6, 7, 10, 14].map((d) => (
										<SelectItem key={d} value={d.toString()}>
											{d} {d === 1 ? "day" : "days"}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>

						<div className="space-y-2">
							<Label htmlFor="mealsPerDay">Meals Per Day</Label>
							<Select value={mealsPerDay} onValueChange={setMealsPerDay}>
								<SelectTrigger id="mealsPerDay">
									<SelectValue />
								</SelectTrigger>
								<SelectContent>
									<SelectItem value="2">2 meals</SelectItem>
									<SelectItem value="3">3 meals</SelectItem>
									<SelectItem value="4">4 meals</SelectItem>
									<SelectItem value="5">5 meals + snacks</SelectItem>
								</SelectContent>
							</Select>
						</div>

						<div className="space-y-2">
							<Label htmlFor="calories">Calories Per Day (Optional)</Label>
							<Input
								id="calories"
								type="number"
								placeholder="e.g., 2000"
								value={caloriesPerDay}
								onChange={(e) => setCaloriesPerDay(e.target.value)}
								min="1000"
								max="5000"
							/>
						</div>
					</div>

					{/* Additional Instructions */}
					<div className="space-y-2">
						<Label htmlFor="instructions">Additional Instructions (Optional)</Label>
						<Textarea
							id="instructions"
							placeholder="e.g., Focus on anti-inflammatory foods, include meal prep tips, prefer one-pot meals..."
							value={additionalInstructions}
							onChange={(e) => setAdditionalInstructions(e.target.value)}
							rows={3}
						/>
					</div>

					{/* Error Alert */}
					{error && (
						<Alert variant="destructive">
							<AlertCircle className="h-4 w-4" />
							<AlertDescription>{error}</AlertDescription>
						</Alert>
					)}

					{/* Submit Button */}
					<Button
						type="submit"
						className="w-full"
						size="lg"
						disabled={isGenerating || restrictions.length === 0}
					>
						{isGenerating ? (
							<>
								<Loader2 className="mr-2 h-5 w-5 animate-spin" />
								Generating Your Meal Plan...
							</>
						) : (
							"Generate Meal Plan"
						)}
					</Button>
				</form>
			</CardContent>
		</Card>
	);
}
