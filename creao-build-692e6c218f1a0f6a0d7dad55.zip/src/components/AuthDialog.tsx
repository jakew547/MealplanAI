import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Sparkles, User, Check } from "lucide-react";

interface AuthDialogProps {
	open: boolean;
	onClose: () => void;
	onLogin: (email: string, isPremium: boolean) => void;
	onUpgradeClick: (email: string) => void;
}

export function AuthDialog({ open, onClose, onLogin, onUpgradeClick }: AuthDialogProps) {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [confirmPassword, setConfirmPassword] = useState("");
	const [error, setError] = useState("");
	const [activeTab, setActiveTab] = useState("login");

	const handleLogin = (e: React.FormEvent) => {
		e.preventDefault();
		setError("");

		if (!email || !password) {
			setError("Please enter both email and password");
			return;
		}

		if (!email.includes("@")) {
			setError("Please enter a valid email address");
			return;
		}

		// Simulate login - create free account
		onLogin(email, false);
		resetForm();
	};

	const handleSignup = (e: React.FormEvent) => {
		e.preventDefault();
		setError("");

		if (!email || !password || !confirmPassword) {
			setError("Please fill in all fields");
			return;
		}

		if (!email.includes("@")) {
			setError("Please enter a valid email address");
			return;
		}

		if (password.length < 6) {
			setError("Password must be at least 6 characters");
			return;
		}

		if (password !== confirmPassword) {
			setError("Passwords do not match");
			return;
		}

		// Simulate signup - create free account
		onLogin(email, false);
		resetForm();
	};

	const handleUpgradeClick = () => {
		if (!email || !email.includes("@")) {
			setError("Please enter a valid email address first");
			return;
		}
		// Close this dialog and open checkout
		onClose();
		onUpgradeClick(email);
	};

	const resetForm = () => {
		setEmail("");
		setPassword("");
		setConfirmPassword("");
		setError("");
	};

	const handleClose = () => {
		resetForm();
		onClose();
	};

	return (
		<Dialog open={open} onOpenChange={handleClose}>
			<DialogContent className="sm:max-w-md">
				<DialogHeader>
					<DialogTitle className="text-2xl">Welcome to MealPlan AI</DialogTitle>
					<DialogDescription>Sign in or create an account to get started</DialogDescription>
				</DialogHeader>

				<Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
					<TabsList className="grid w-full grid-cols-2">
						<TabsTrigger value="login">Sign In</TabsTrigger>
						<TabsTrigger value="signup">Sign Up</TabsTrigger>
					</TabsList>

					<TabsContent value="login" className="space-y-4">
						<form onSubmit={handleLogin} className="space-y-4">
							<div className="space-y-2">
								<Label htmlFor="login-email">Email</Label>
								<Input
									id="login-email"
									type="email"
									placeholder="you@example.com"
									value={email}
									onChange={(e) => setEmail(e.target.value)}
									autoComplete="email"
								/>
							</div>
							<div className="space-y-2">
								<Label htmlFor="login-password">Password</Label>
								<Input
									id="login-password"
									type="password"
									placeholder="Enter your password"
									value={password}
									onChange={(e) => setPassword(e.target.value)}
									autoComplete="current-password"
								/>
							</div>

							{error && (
								<Alert variant="destructive">
									<AlertDescription>{error}</AlertDescription>
								</Alert>
							)}

							<Button type="submit" className="w-full" size="lg">
								<User className="w-4 h-4 mr-2" />
								Sign In
							</Button>
						</form>

						<div className="text-center text-sm text-gray-500">
							Demo mode: Use any email and password to continue
						</div>
					</TabsContent>

					<TabsContent value="signup" className="space-y-4">
						<form onSubmit={handleSignup} className="space-y-4">
							<div className="space-y-2">
								<Label htmlFor="signup-email">Email</Label>
								<Input
									id="signup-email"
									type="email"
									placeholder="you@example.com"
									value={email}
									onChange={(e) => setEmail(e.target.value)}
									autoComplete="email"
								/>
							</div>
							<div className="space-y-2">
								<Label htmlFor="signup-password">Password</Label>
								<Input
									id="signup-password"
									type="password"
									placeholder="At least 6 characters"
									value={password}
									onChange={(e) => setPassword(e.target.value)}
									autoComplete="new-password"
								/>
							</div>
							<div className="space-y-2">
								<Label htmlFor="confirm-password">Confirm Password</Label>
								<Input
									id="confirm-password"
									type="password"
									placeholder="Re-enter your password"
									value={confirmPassword}
									onChange={(e) => setConfirmPassword(e.target.value)}
									autoComplete="new-password"
								/>
							</div>

							{error && (
								<Alert variant="destructive">
									<AlertDescription>{error}</AlertDescription>
								</Alert>
							)}

							<Button type="submit" className="w-full" size="lg">
								<User className="w-4 h-4 mr-2" />
								Create Free Account
							</Button>
						</form>

						<div className="text-center text-sm text-gray-500">
							Demo mode: Use any email and password to continue
						</div>
					</TabsContent>
				</Tabs>

				{/* Premium Benefits */}
				<div className="mt-4 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
					<h4 className="font-semibold text-purple-900 mb-2 flex items-center gap-2">
						<Sparkles className="w-4 h-4" />
						Upgrade to Premium
					</h4>
					<div className="grid grid-cols-2 gap-2 mb-3">
						<div className="text-center p-2 bg-white rounded border border-purple-200">
							<p className="text-2xl font-bold text-purple-900">$4.99</p>
							<p className="text-xs text-purple-600">per month</p>
						</div>
						<div className="text-center p-2 bg-white rounded border border-purple-200 relative">
							<div className="absolute -top-1 -right-1 bg-green-500 text-white text-[10px] px-1 rounded">Save $10</div>
							<p className="text-2xl font-bold text-purple-900">$50</p>
							<p className="text-xs text-purple-600">per year</p>
						</div>
					</div>
					<ul className="text-sm text-purple-700 space-y-1 mb-3">
						<li className="flex items-center gap-2">
							<Check className="w-3 h-3 flex-shrink-0" />
							<span>Unlimited AI-generated meal plans</span>
						</li>
						<li className="flex items-center gap-2">
							<Check className="w-3 h-3 flex-shrink-0" />
							<span>Export grocery lists & meal plans</span>
						</li>
						<li className="flex items-center gap-2">
							<Check className="w-3 h-3 flex-shrink-0" />
							<span>Regenerate individual meals</span>
						</li>
					</ul>
					<Button
						onClick={handleUpgradeClick}
						className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
						size="sm"
					>
						<Sparkles className="w-4 h-4 mr-2" />
						Upgrade to Premium
					</Button>
				</div>
			</DialogContent>
		</Dialog>
	);
}
