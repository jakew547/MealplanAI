import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Check } from "lucide-react";

interface SubscriptionBannerProps {
	onUpgrade: () => void;
}

export function SubscriptionBanner({ onUpgrade }: SubscriptionBannerProps) {
	return (
		<Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200 mb-6">
			<CardContent className="p-6">
				<div className="flex items-center justify-between gap-6">
					<div className="flex items-start gap-4 flex-1">
						<div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
							<Sparkles className="w-6 h-6 text-white" />
						</div>
						<div className="flex-1">
							<div className="flex items-center gap-2 mb-2">
								<h3 className="text-lg font-bold text-purple-900">Upgrade to Premium</h3>
								<Badge className="bg-gradient-to-r from-purple-500 to-pink-500">Save $10</Badge>
							</div>
							<p className="text-sm text-purple-700 mb-3">
								Unlock unlimited custom meal plans, grocery list exports, and advanced dietary customization
							</p>
							<div className="grid grid-cols-2 gap-2">
								<div className="flex items-center gap-2 text-sm text-purple-800">
									<Check className="w-4 h-4 text-green-600" />
									<span>Unlimited meal plans</span>
								</div>
								<div className="flex items-center gap-2 text-sm text-purple-800">
									<Check className="w-4 h-4 text-green-600" />
									<span>Grocery list exports</span>
								</div>
								<div className="flex items-center gap-2 text-sm text-purple-800">
									<Check className="w-4 h-4 text-green-600" />
									<span>Recipe regeneration</span>
								</div>
								<div className="flex items-center gap-2 text-sm text-purple-800">
									<Check className="w-4 h-4 text-green-600" />
									<span>Meal plan history</span>
								</div>
							</div>
						</div>
					</div>
					<div className="flex flex-col gap-3">
						<div className="text-center">
							<p className="text-3xl font-bold text-purple-900">$4.99</p>
							<p className="text-sm text-purple-600">per month</p>
						</div>
						<div className="text-center">
							<p className="text-2xl font-bold text-purple-900">$50</p>
							<p className="text-sm text-purple-600">per year</p>
							<p className="text-xs text-green-600 font-semibold mt-1">Save $10/year</p>
						</div>
						<Button onClick={onUpgrade} size="lg" className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
							<Sparkles className="w-4 h-4 mr-2" />
							Upgrade Now
						</Button>
					</div>
				</div>
			</CardContent>
		</Card>
	);
}
