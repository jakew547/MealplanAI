import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { type HealthGoal, type DietaryProfile, type SupplementTarget } from "@/hooks/use-meal-planner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
	Target,
	Dumbbell,
	TrendingDown,
	TrendingUp,
	Heart,
	Zap,
	Apple,
	Shield,
	Plus,
	X,
	ChevronRight,
	ChevronLeft,
	Clock,
	ChefHat,
	Sparkles,
	ArrowLeft,
	ArrowRight,
} from "lucide-react";

export type MealComplexity = "quick" | "moderate" | "gourmet";

interface MealPlanWizardProps {
	onComplete: (
		profile: DietaryProfile,
		healthGoal: HealthGoal,
		supplements: SupplementTarget[],
		options: {
			days: number;
			caloriesPerDay?: number;
			mealsPerDay: number;
			complexity?: MealComplexity;
			additionalInstructions?: string;
			cheatMealsPerMonth?: number;
		}
	) => void;
	isGenerating: boolean;
}

const HEALTH_GOALS = [
	{
		id: "weight-loss" as const,
		name: "Lose Weight",
		description: "Calorie deficit with balanced macros",
		icon: TrendingDown,
		color: "from-red-500 to-orange-500",
	},
	{
		id: "muscle-gain" as const,
		name: "Build Muscle",
		description: "High protein, calorie surplus",
		icon: Dumbbell,
		color: "from-blue-500 to-cyan-500",
	},
	{
		id: "get-lean" as const,
		name: "Get Lean",
		description: "Maintain muscle while cutting fat",
		icon: Target,
		color: "from-purple-500 to-pink-500",
	},
	{
		id: "weight-gain" as const,
		name: "Gain Weight",
		description: "Healthy calorie surplus",
		icon: TrendingUp,
		color: "from-green-500 to-emerald-500",
	},
	{
		id: "heart-health" as const,
		name: "Heart Health",
		description: "Low sodium, healthy fats",
		icon: Heart,
		color: "from-red-400 to-rose-500",
	},
	{
		id: "energy-boost" as const,
		name: "Boost Energy",
		description: "Sustained energy throughout the day",
		icon: Zap,
		color: "from-yellow-500 to-amber-500",
	},
	{
		id: "general-health" as const,
		name: "General Health",
		description: "Balanced, nutrient-rich meals",
		icon: Apple,
		color: "from-green-600 to-lime-500",
	},
	{
		id: "immune-support" as const,
		name: "Immune Support",
		description: "Vitamin-rich, anti-inflammatory",
		icon: Shield,
		color: "from-indigo-500 to-violet-500",
	},
];

const SUPPLEMENT_TARGETS = [
	{ id: "protein", name: "High Protein", description: "For muscle growth & recovery" },
	{ id: "fiber", name: "High Fiber", description: "For digestive health" },
	{ id: "iron", name: "Iron", description: "For energy & blood health" },
	{ id: "calcium", name: "Calcium", description: "For bone health" },
	{ id: "vitamin-d", name: "Vitamin D", description: "For bone & immune health" },
	{ id: "vitamin-c", name: "Vitamin C", description: "For immune support" },
	{ id: "omega-3", name: "Omega-3", description: "For heart & brain health" },
	{ id: "b-vitamins", name: "B Vitamins", description: "For energy metabolism" },
	{ id: "magnesium", name: "Magnesium", description: "For muscle & nerve function" },
	{ id: "zinc", name: "Zinc", description: "For immune & wound healing" },
	{ id: "antioxidants", name: "Antioxidants", description: "For cell protection" },
	{ id: "probiotics", name: "Probiotics", description: "For gut health" },
];

const COMMON_RESTRICTIONS = [
	"gluten-free",
	"dairy-free",
	"nut-free",
	"shellfish-free",
	"egg-free",
	"soy-free",
	"vegan",
	"vegetarian",
	"keto",
	"paleo",
	"low-FODMAP",
	"AIP",
];

export function MealPlanWizard({ onComplete, isGenerating }: MealPlanWizardProps) {
	const [step, setStep] = useState(1);
	const [selectedGoal, setSelectedGoal] = useState<HealthGoal | null>(null);
	const [selectedSupplements, setSelectedSupplements] = useState<SupplementTarget[]>([]);
	const [restrictions, setRestrictions] = useState<string[]>([]);
	const [customRestriction, setCustomRestriction] = useState("");
	const [allergies, setAllergies] = useState<string[]>([]);
	const [allergyInput, setAllergyInput] = useState("");
	const [days, setDays] = useState(7);
	const [caloriesPerDay, setCaloriesPerDay] = useState("");
	const [mealsPerDay, setMealsPerDay] = useState(3);
	const [complexity, setComplexity] = useState<MealComplexity>("moderate");
	const [cheatMealsPerMonth, setCheatMealsPerMonth] = useState(4);

	const totalSteps = 5;
	const progress = (step / totalSteps) * 100;

	const toggleSupplement = (supplementId: string) => {
		const supplement = SUPPLEMENT_TARGETS.find((s) => s.id === supplementId);
		if (!supplement) return;

		if (selectedSupplements.some((s) => s.id === supplementId)) {
			setSelectedSupplements(selectedSupplements.filter((s) => s.id !== supplementId));
		} else {
			setSelectedSupplements([
				...selectedSupplements,
				{ id: supplement.id, name: supplement.name, targetAmount: "high" },
			]);
		}
	};

	const addRestriction = (restriction: string) => {
		if (restriction && !restrictions.includes(restriction)) {
			setRestrictions([...restrictions, restriction]);
		}
		setCustomRestriction("");
	};

	const removeRestriction = (restriction: string) => {
		setRestrictions(restrictions.filter((r) => r !== restriction));
	};

	const addAllergy = () => {
		if (allergyInput.trim() && !allergies.includes(allergyInput.trim())) {
			setAllergies([...allergies, allergyInput.trim()]);
			setAllergyInput("");
		}
	};

	const removeAllergy = (allergy: string) => {
		setAllergies(allergies.filter((a) => a !== allergy));
	};

	const handleComplete = () => {
		if (!selectedGoal) return;

		const profile: DietaryProfile = {
			restrictions: restrictions.length > 0 ? restrictions : undefined,
			allergies: allergies.length > 0 ? allergies : undefined,
		};

		onComplete(profile, selectedGoal, selectedSupplements, {
			days,
			caloriesPerDay: caloriesPerDay ? parseInt(caloriesPerDay) : undefined,
			mealsPerDay,
			complexity,
			cheatMealsPerMonth,
		});
	};

	const canProceed = () => {
		if (step === 1) return selectedGoal !== null;
		return true;
	};

	return (
		<div className="max-w-5xl mx-auto">
			{/* Progress Bar */}
			<div className="mb-8">
				<div className="flex justify-between items-center mb-3">
					<h2 className="text-2xl font-bold">Create Your Meal Plan</h2>
					<span className="text-sm text-gray-600">
						Step {step} of {totalSteps}
					</span>
				</div>
				<Progress value={progress} className="h-2" />
			</div>

			<AnimatePresence mode="wait">
				{/* Step 1: Health Goal Selection */}
				{step === 1 && (
					<motion.div
						key="step1"
						initial={{ opacity: 0, x: 50 }}
						animate={{ opacity: 1, x: 0 }}
						exit={{ opacity: 0, x: -50 }}
						transition={{ duration: 0.3 }}
					>
						<Card>
							<CardContent className="p-8">
								<div className="text-center mb-8">
									<h3 className="text-3xl font-bold mb-2">What's Your Goal?</h3>
									<p className="text-gray-600">Choose the health goal that matters most to you</p>
								</div>

								<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
									{HEALTH_GOALS.map((goal) => {
										const Icon = goal.icon;
										const isSelected = selectedGoal === goal.id;

										return (
											<motion.div
												key={goal.id}
												whileHover={{ scale: 1.05 }}
												whileTap={{ scale: 0.95 }}
												transition={{ type: "spring", stiffness: 400, damping: 17 }}
											>
												<Card
													className={`cursor-pointer transition-all border-2 ${
														isSelected
															? "border-primary shadow-lg"
															: "border-transparent hover:border-gray-300"
													}`}
													onClick={() => setSelectedGoal(goal.id)}
												>
													<CardContent className="p-6 text-center">
														<div
															className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${goal.color} flex items-center justify-center shadow-lg`}
														>
															<Icon className="w-8 h-8 text-white" />
														</div>
														<h4 className="font-bold mb-1 text-lg">{goal.name}</h4>
														<p className="text-sm text-gray-600">{goal.description}</p>
													</CardContent>
												</Card>
											</motion.div>
										);
									})}
								</div>
							</CardContent>
						</Card>
					</motion.div>
				)}

				{/* Step 2: Supplement Targeting */}
				{step === 2 && (
					<motion.div
						key="step2"
						initial={{ opacity: 0, x: 50 }}
						animate={{ opacity: 1, x: 0 }}
						exit={{ opacity: 0, x: -50 }}
						transition={{ duration: 0.3 }}
					>
						<Card>
							<CardContent className="p-8">
								<div className="text-center mb-8">
									<h3 className="text-3xl font-bold mb-2">Target Specific Nutrients</h3>
									<p className="text-gray-600">Select nutrients you'd like to prioritize (optional)</p>
								</div>

								<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
									{SUPPLEMENT_TARGETS.map((supplement) => {
										const isSelected = selectedSupplements.some((s) => s.id === supplement.id);

										return (
											<motion.div
												key={supplement.id}
												whileHover={{ scale: 1.02 }}
												whileTap={{ scale: 0.98 }}
											>
												<Card
													className={`cursor-pointer transition-all border-2 ${
														isSelected
															? "border-primary bg-primary/5"
															: "border-gray-200 hover:border-gray-300"
													}`}
													onClick={() => toggleSupplement(supplement.id)}
												>
													<CardContent className="p-4">
														<div className="flex items-start justify-between">
															<div>
																<h4 className="font-semibold mb-1">{supplement.name}</h4>
																<p className="text-xs text-gray-600">{supplement.description}</p>
															</div>
															{isSelected && (
																<div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
																	<div className="w-2 h-2 bg-white rounded-full" />
																</div>
															)}
														</div>
													</CardContent>
												</Card>
											</motion.div>
										);
									})}
								</div>

								{selectedSupplements.length > 0 && (
									<div className="mt-6 p-4 bg-blue-50 rounded-lg">
										<p className="text-sm font-medium text-blue-900 mb-2">
											Selected Targets ({selectedSupplements.length})
										</p>
										<div className="flex flex-wrap gap-2">
											{selectedSupplements.map((supplement) => (
												<Badge key={supplement.id} variant="secondary">
													{supplement.name}
												</Badge>
											))}
										</div>
									</div>
								)}
							</CardContent>
						</Card>
					</motion.div>
				)}

				{/* Step 3: Dietary Restrictions (Optional) */}
				{step === 3 && (
					<motion.div
						key="step3"
						initial={{ opacity: 0, x: 50 }}
						animate={{ opacity: 1, x: 0 }}
						exit={{ opacity: 0, x: -50 }}
						transition={{ duration: 0.3 }}
					>
						<Card>
							<CardContent className="p-8">
								<div className="text-center mb-8">
									<h3 className="text-3xl font-bold mb-2">Any Dietary Restrictions?</h3>
									<p className="text-gray-600">
										Add restrictions or allergies if needed (completely optional)
									</p>
								</div>

								<div className="space-y-6">
									{/* Dietary Restrictions */}
									<div className="space-y-3">
										<Label className="text-base font-semibold">Dietary Restrictions</Label>
										<div className="flex flex-wrap gap-2">
											{COMMON_RESTRICTIONS.map((restriction) => (
												<Badge
													key={restriction}
													variant={restrictions.includes(restriction) ? "default" : "outline"}
													className="cursor-pointer"
													onClick={() => {
														if (restrictions.includes(restriction)) {
															removeRestriction(restriction);
														} else {
															addRestriction(restriction);
														}
													}}
												>
													{restriction}
													{restrictions.includes(restriction) && <X className="ml-1 w-3 h-3" />}
												</Badge>
											))}
										</div>
										<div className="flex gap-2">
											<Input
												placeholder="Add custom restriction..."
												value={customRestriction}
												onChange={(e) => setCustomRestriction(e.target.value)}
												onKeyDown={(e) => {
													if (e.key === "Enter") {
														e.preventDefault();
														addRestriction(customRestriction);
													}
												}}
											/>
											<Button
												type="button"
												variant="outline"
												size="icon"
												onClick={() => addRestriction(customRestriction)}
											>
												<Plus className="w-4 h-4" />
											</Button>
										</div>
									</div>

									{/* Allergies */}
									<div className="space-y-3">
										<Label className="text-base font-semibold">Allergies (Strict Exclusion)</Label>
										<div className="flex flex-wrap gap-2 min-h-[32px]">
											{allergies.map((allergy) => (
												<Badge key={allergy} variant="destructive">
													{allergy}
													<button
														type="button"
														onClick={() => removeAllergy(allergy)}
														className="ml-1 hover:bg-red-700 rounded-full"
													>
														<X className="w-3 h-3" />
													</button>
												</Badge>
											))}
										</div>
										<div className="flex gap-2">
											<Input
												placeholder="e.g., peanuts, shellfish, tree nuts..."
												value={allergyInput}
												onChange={(e) => setAllergyInput(e.target.value)}
												onKeyDown={(e) => {
													if (e.key === "Enter") {
														e.preventDefault();
														addAllergy();
													}
												}}
											/>
											<Button type="button" variant="outline" size="icon" onClick={addAllergy}>
												<Plus className="w-4 h-4" />
											</Button>
										</div>
									</div>
								</div>
							</CardContent>
						</Card>
					</motion.div>
				)}

				{/* Step 4: Cheat Meals */}
				{step === 4 && (
					<motion.div
						key="step4"
						initial={{ opacity: 0, x: 50 }}
						animate={{ opacity: 1, x: 0 }}
						exit={{ opacity: 0, x: -50 }}
						transition={{ duration: 0.3 }}
						className="relative overflow-hidden"
					>
						{/* Animated Gradient Background */}
						<div className="absolute inset-0 bg-gradient-to-br from-pink-400 via-purple-500 to-indigo-600 animate-gradient-xy opacity-90 rounded-lg" />

						{/* Floating Stars */}
						{[...Array(12)].map((_, i) => (
							<motion.div
								key={i}
								className="absolute text-4xl"
								initial={{
									x: `${Math.random() * 100}%`,
									y: `${Math.random() * 100}%`,
									opacity: 0,
									scale: 0.5
								}}
								animate={{
									x: [`${Math.random() * 100}%`, `${Math.random() * 100}%`, `${Math.random() * 100}%`],
									y: [`${Math.random() * 100}%`, `${Math.random() * 100}%`, `${Math.random() * 100}%`],
									opacity: [0, 1, 0.7, 1, 0],
									scale: [0.5, 1.2, 0.8, 1, 0.5],
									rotate: [0, 360, 180, 360]
								}}
								transition={{
									duration: 8 + Math.random() * 4,
									repeat: Number.POSITIVE_INFINITY,
									delay: Math.random() * 2,
									ease: "easeInOut"
								}}
							>
								⭐
							</motion.div>
						))}

						{/* Content */}
						<Card className="relative bg-white/95 backdrop-blur-sm border-2 border-white/50 shadow-2xl">
							<CardContent className="p-8 md:p-12">
								<div className="text-center mb-8 space-y-4">
									<motion.h3
										className="text-4xl md:text-5xl font-black text-black leading-tight"
										initial={{ scale: 0.8, opacity: 0 }}
										animate={{ scale: 1, opacity: 1 }}
										transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
									>
										Everyone needs a cheat meal
									</motion.h3>
									<motion.p
										className="text-lg text-gray-700"
										initial={{ opacity: 0 }}
										animate={{ opacity: 1 }}
										transition={{ delay: 0.4 }}
									>
										Balance is key to sustainable healthy eating
									</motion.p>
								</div>

								<div className="max-w-2xl mx-auto space-y-8">
									{/* Slider Controls */}
									<div className="space-y-6">
										<Label className="text-xl font-bold text-center block">
											Cheat Meals Per Month
										</Label>

										<div className="flex items-center justify-center gap-4">
											<Button
												type="button"
												variant="outline"
												size="icon"
												className="h-12 w-12 rounded-full bg-white shadow-lg hover:scale-110 transition-transform"
												onClick={() => setCheatMealsPerMonth(Math.max(0, cheatMealsPerMonth - 1))}
												disabled={cheatMealsPerMonth === 0}
											>
												<ArrowLeft className="h-6 w-6" />
											</Button>

											<motion.div
												className="text-center min-w-[200px]"
												key={cheatMealsPerMonth}
												initial={{ scale: 1.2 }}
												animate={{ scale: 1 }}
												transition={{ type: "spring", stiffness: 300 }}
											>
												<div className="text-7xl font-black bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 bg-clip-text text-transparent">
													{cheatMealsPerMonth}
												</div>
												<div className="text-sm text-gray-600 mt-2">
													{cheatMealsPerMonth === 1 ? "meal" : "meals"} per month
												</div>
											</motion.div>

											<Button
												type="button"
												variant="outline"
												size="icon"
												className="h-12 w-12 rounded-full bg-white shadow-lg hover:scale-110 transition-transform"
												onClick={() => setCheatMealsPerMonth(Math.min(30, cheatMealsPerMonth + 1))}
												disabled={cheatMealsPerMonth === 30}
											>
												<ArrowRight className="h-6 w-6" />
											</Button>
										</div>

										{/* Weekly Summary */}
										<motion.div
											className="text-center p-6 bg-gradient-to-r from-pink-50 via-purple-50 to-indigo-50 rounded-xl border-2 border-purple-200"
											key={`summary-${cheatMealsPerMonth}`}
											initial={{ opacity: 0, y: 10 }}
											animate={{ opacity: 1, y: 0 }}
										>
											<p className="text-lg font-semibold text-gray-800">
												That's approximately{" "}
												<span className="text-2xl font-black bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
													{(cheatMealsPerMonth / 4.33).toFixed(1)}
												</span>{" "}
												cheat {(cheatMealsPerMonth / 4.33) === 1 ? "meal" : "meals"} per week
											</p>
											<p className="text-sm text-gray-600 mt-2">
												{cheatMealsPerMonth === 0
													? "No cheat meals - full discipline mode!"
													: cheatMealsPerMonth <= 4
													? "Great balance for steady progress"
													: cheatMealsPerMonth <= 8
													? "Flexible approach for sustainability"
													: "Enjoying life while staying healthy"}
											</p>
										</motion.div>

										{/* Skip Option */}
										<div className="text-center pt-4">
											<Button
												type="button"
												variant="ghost"
												onClick={() => {
													setCheatMealsPerMonth(0);
													setStep(step + 1);
												}}
												className="text-gray-600 hover:text-gray-900"
											>
												Skip cheat meals entirely
											</Button>
										</div>
									</div>
								</div>
							</CardContent>
						</Card>
					</motion.div>
				)}

				{/* Step 5: Plan Customization */}
				{step === 5 && (
					<motion.div
						key="step5"
						initial={{ opacity: 0, x: 50 }}
						animate={{ opacity: 1, x: 0 }}
						exit={{ opacity: 0, x: -50 }}
						transition={{ duration: 0.3 }}
					>
						<Card>
							<CardContent className="p-8">
								<div className="text-center mb-8">
									<h3 className="text-3xl font-bold mb-2">Customize Your Plan</h3>
									<p className="text-gray-600">Final details for your personalized meal plan</p>
								</div>

								<div className="max-w-2xl mx-auto space-y-6">
									<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
										<div className="space-y-2">
											<Label htmlFor="days" className="text-base">
												Number of Days
											</Label>
											<div className="flex gap-2">
												{[3, 5, 7, 14].map((d) => (
													<Button
														key={d}
														type="button"
														variant={days === d ? "default" : "outline"}
														className="flex-1"
														onClick={() => setDays(d)}
													>
														{d}
													</Button>
												))}
											</div>
										</div>

										<div className="space-y-2">
											<Label htmlFor="mealsPerDay" className="text-base">
												Meals Per Day
											</Label>
											<div className="flex gap-2">
												{[2, 3, 4].map((m) => (
													<Button
														key={m}
														type="button"
														variant={mealsPerDay === m ? "default" : "outline"}
														className="flex-1"
														onClick={() => setMealsPerDay(m)}
													>
														{m}
													</Button>
												))}
											</div>
										</div>
									</div>

									{/* Meal Complexity */}
									<div className="space-y-3">
										<Label className="text-base font-semibold">Meal Complexity & Prep Time</Label>
										<p className="text-sm text-gray-600">Choose how much time you want to spend preparing meals</p>
										<div className="grid grid-cols-1 md:grid-cols-3 gap-3">
											<motion.div
												whileHover={{ scale: 1.02 }}
												whileTap={{ scale: 0.98 }}
											>
												<Card
													className={`cursor-pointer transition-all border-2 ${
														complexity === "quick"
															? "border-primary bg-primary/5"
															: "border-gray-200 hover:border-gray-300"
													}`}
													onClick={() => setComplexity("quick")}
												>
													<CardContent className="p-4">
														<div className="flex flex-col items-center text-center space-y-2">
															<div className={`w-12 h-12 rounded-full flex items-center justify-center ${
																complexity === "quick" ? "bg-primary" : "bg-gray-100"
															}`}>
																<Clock className={`w-6 h-6 ${complexity === "quick" ? "text-white" : "text-gray-600"}`} />
															</div>
															<div>
																<h4 className="font-semibold">Quick & Easy</h4>
																<p className="text-xs text-gray-600">15-30 min prep</p>
																<p className="text-xs text-gray-500 mt-1">Simple recipes, minimal ingredients</p>
															</div>
														</div>
													</CardContent>
												</Card>
											</motion.div>

											<motion.div
												whileHover={{ scale: 1.02 }}
												whileTap={{ scale: 0.98 }}
											>
												<Card
													className={`cursor-pointer transition-all border-2 ${
														complexity === "moderate"
															? "border-primary bg-primary/5"
															: "border-gray-200 hover:border-gray-300"
													}`}
													onClick={() => setComplexity("moderate")}
												>
													<CardContent className="p-4">
														<div className="flex flex-col items-center text-center space-y-2">
															<div className={`w-12 h-12 rounded-full flex items-center justify-center ${
																complexity === "moderate" ? "bg-primary" : "bg-gray-100"
															}`}>
																<ChefHat className={`w-6 h-6 ${complexity === "moderate" ? "text-white" : "text-gray-600"}`} />
															</div>
															<div>
																<h4 className="font-semibold">Moderate</h4>
																<p className="text-xs text-gray-600">30-45 min prep</p>
																<p className="text-xs text-gray-500 mt-1">Balanced complexity and variety</p>
															</div>
														</div>
													</CardContent>
												</Card>
											</motion.div>

											<motion.div
												whileHover={{ scale: 1.02 }}
												whileTap={{ scale: 0.98 }}
											>
												<Card
													className={`cursor-pointer transition-all border-2 ${
														complexity === "gourmet"
															? "border-primary bg-primary/5"
															: "border-gray-200 hover:border-gray-300"
													}`}
													onClick={() => setComplexity("gourmet")}
												>
													<CardContent className="p-4">
														<div className="flex flex-col items-center text-center space-y-2">
															<div className={`w-12 h-12 rounded-full flex items-center justify-center ${
																complexity === "gourmet" ? "bg-primary" : "bg-gray-100"
															}`}>
																<Sparkles className={`w-6 h-6 ${complexity === "gourmet" ? "text-white" : "text-gray-600"}`} />
															</div>
															<div>
																<h4 className="font-semibold">Gourmet</h4>
																<p className="text-xs text-gray-600">45+ min prep</p>
																<p className="text-xs text-gray-500 mt-1">Restaurant-quality, detailed recipes</p>
															</div>
														</div>
													</CardContent>
												</Card>
											</motion.div>
										</div>
									</div>

									<div className="space-y-2">
										<Label htmlFor="calories" className="text-base">
											Target Calories Per Day (Optional)
										</Label>
										<Input
											id="calories"
											type="number"
											placeholder="e.g., 2000"
											value={caloriesPerDay}
											onChange={(e) => setCaloriesPerDay(e.target.value)}
											min="1000"
											max="5000"
											className="text-lg p-6"
										/>
										<p className="text-sm text-gray-500">Leave empty for automatic calculation based on your goal</p>
									</div>

									{/* Summary */}
									<div className="mt-8 p-6 bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg space-y-3">
										<h4 className="font-bold text-lg">Plan Summary</h4>
										<div className="space-y-2 text-sm">
											<div className="flex justify-between">
												<span className="text-gray-600">Goal:</span>
												<span className="font-semibold">
													{HEALTH_GOALS.find((g) => g.id === selectedGoal)?.name}
												</span>
											</div>
											{selectedSupplements.length > 0 && (
												<div className="flex justify-between">
													<span className="text-gray-600">Targeting:</span>
													<span className="font-semibold">{selectedSupplements.length} nutrients</span>
												</div>
											)}
											{restrictions.length > 0 && (
												<div className="flex justify-between">
													<span className="text-gray-600">Restrictions:</span>
													<span className="font-semibold">{restrictions.length} dietary restrictions</span>
												</div>
											)}
											{allergies.length > 0 && (
												<div className="flex justify-between">
													<span className="text-gray-600">Allergies:</span>
													<span className="font-semibold">{allergies.length} allergens excluded</span>
												</div>
											)}
											<div className="flex justify-between">
												<span className="text-gray-600">Duration:</span>
												<span className="font-semibold">{days} days</span>
											</div>
											<div className="flex justify-between">
												<span className="text-gray-600">Meals:</span>
												<span className="font-semibold">{mealsPerDay} per day</span>
											</div>
										</div>
									</div>
								</div>
							</CardContent>
						</Card>
					</motion.div>
				)}
			</AnimatePresence>

			{/* Navigation Buttons */}
			<div className="flex justify-between mt-6">
				<Button
					variant="outline"
					size="lg"
					onClick={() => setStep(step - 1)}
					disabled={step === 1 || isGenerating}
				>
					<ChevronLeft className="w-4 h-4 mr-2" />
					Back
				</Button>

				{step < totalSteps ? (
					<Button size="lg" onClick={() => setStep(step + 1)} disabled={!canProceed() || isGenerating}>
						Next
						<ChevronRight className="w-4 h-4 ml-2" />
					</Button>
				) : (
					<Button size="lg" onClick={handleComplete} disabled={!canProceed() || isGenerating}>
						Generate Plan
						<ChevronRight className="w-4 h-4 ml-2" />
					</Button>
				)}
			</div>
		</div>
	);
}
