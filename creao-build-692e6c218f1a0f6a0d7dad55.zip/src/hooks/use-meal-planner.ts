import { useMutation, type UseMutationResult } from '@tanstack/react-query';
import { createChatCompletion } from '@/sdk/api-clients/OpenAIGPTChat';

// Dietary restriction types
export type DietaryRestriction =
  | 'AIP'
  | 'low-FODMAP'
  | 'gluten-free'
  | 'dairy-free'
  | 'nut-free'
  | 'shellfish-free'
  | 'egg-free'
  | 'soy-free'
  | string;

// Health goal types
export type HealthGoal =
  | 'weight-loss'
  | 'muscle-gain'
  | 'get-lean'
  | 'weight-gain'
  | 'heart-health'
  | 'energy-boost'
  | 'general-health'
  | 'immune-support';

// Supplement targeting
export interface SupplementTarget {
  id: string;
  name: string;
  targetAmount: 'high' | 'moderate' | 'low';
}

export interface DietaryProfile {
  restrictions?: DietaryRestriction[];
  allergies?: string[];
  intolerances?: string[];
  medicalConditions?: string[];
  preferences?: string[];
}

export type MealComplexity = 'quick' | 'moderate' | 'gourmet';

export interface MealPlanInput {
  dietaryProfile: DietaryProfile;
  healthGoal?: HealthGoal;
  supplements?: SupplementTarget[];
  days?: number;
  caloriesPerDay?: number;
  mealsPerDay?: number;
  complexity?: MealComplexity;
  additionalInstructions?: string;
  cheatMealsPerMonth?: number;
}

export interface NutritionalInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber?: number;
  sodium?: number;
}

export interface Meal {
  name: string;
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  isCheatMeal?: boolean;
  ingredients: Array<{
    item: string;
    quantity: string;
    notes?: string;
  }>;
  instructions: string[];
  prepTime: number;
  cookTime: number;
  servings: number;
  nutrition: NutritionalInfo;
  dietaryCompliance: string[];
}

export interface DayPlan {
  day: number;
  date?: string;
  meals: Meal[];
  totalNutrition: NutritionalInfo;
}

export interface MealPlanResponse {
  weeklyPlan: DayPlan[];
  shoppingList: Array<{
    item: string;
    quantity: string;
    category: string;
    suggestedBrands?: string[];
  }>;
  mealPrepTips?: string[];
  dietaryNotes?: string[];
}

export interface MealPlannerError extends Error {
  code?: string;
  details?: unknown;
}

/**
 * Creates a system prompt for meal planning with dietary restrictions
 */
function createMealPlannerSystemPrompt(dietaryProfile: DietaryProfile, healthGoal?: HealthGoal, supplements?: SupplementTarget[]): string {
  const { restrictions, allergies, intolerances, medicalConditions, preferences } = dietaryProfile;

  let prompt = `You are an expert nutritionist and meal planner specializing in dietary restrictions and medical nutrition therapy.

Your task is to create personalized meal plans that strictly comply with the following dietary requirements:
`;

  if (healthGoal) {
    const goalDescriptions: Record<HealthGoal, string> = {
      'weight-loss': 'Create meals optimized for weight loss with a calorie deficit and balanced macros',
      'muscle-gain': 'Create high-protein meals with a calorie surplus to support muscle growth',
      'get-lean': 'Create meals to maintain muscle while reducing body fat',
      'weight-gain': 'Create nutrient-dense meals with healthy calorie surplus for weight gain',
      'heart-health': 'Create heart-healthy meals low in sodium and saturated fats, rich in omega-3s',
      'energy-boost': 'Create meals that provide sustained energy throughout the day',
      'general-health': 'Create balanced, nutrient-rich meals for overall health',
      'immune-support': 'Create vitamin-rich, anti-inflammatory meals to support immune function',
    };
    prompt += `\nHEALTH GOAL: ${goalDescriptions[healthGoal]}\n`;
  }

  if (supplements && supplements.length > 0) {
    prompt += `\nNUTRIENT TARGETS (prioritize these in meals):
${supplements.map((s) => `- ${s.name} (${s.targetAmount} amount)`).join('\n')}
`;
  }

  if (restrictions && restrictions.length > 0) {
    prompt += `\nDIETARY RESTRICTIONS:
${restrictions.map((r) => `- ${r}`).join('\n')}
`;
  }

  if (allergies && allergies.length > 0) {
    prompt += `\nALLERGIES (STRICT EXCLUSION):
${allergies.map((a) => `- ${a}`).join('\n')}
`;
  }

  if (intolerances && intolerances.length > 0) {
    prompt += `\nINTOLERANCES (AVOID):
${intolerances.map((i) => `- ${i}`).join('\n')}
`;
  }

  if (medicalConditions && medicalConditions.length > 0) {
    prompt += `\nMEDICAL CONDITIONS TO CONSIDER:
${medicalConditions.map((m) => `- ${m}`).join('\n')}
`;
  }

  if (preferences && preferences.length > 0) {
    prompt += `\nPREFERENCES:
${preferences.map((p) => `- ${p}`).join('\n')}
`;
  }

  prompt += `\nIMPORTANT GUIDELINES:
1. All meals MUST be 100% compliant with the specified dietary restrictions
2. Double-check every ingredient for hidden allergens and problematic compounds
3. Provide detailed nutritional information for each meal
4. Include prep time, cook time, and clear step-by-step instructions
5. Ensure variety in meals throughout the week
6. Balance macronutrients appropriately for the dietary profile
7. Include a comprehensive shopping list organized by category with healthy, well-rated brand suggestions

OUTPUT FORMAT:
Return ONLY valid JSON matching this exact structure (no markdown, no code blocks):
{
  "weeklyPlan": [
    {
      "day": 1,
      "meals": [
        {
          "name": "Meal Name",
          "type": "breakfast|lunch|dinner|snack",
          "isCheatMeal": false,
          "ingredients": [{"item": "ingredient", "quantity": "amount", "notes": "optional"}],
          "instructions": ["step 1", "step 2"],
          "prepTime": 15,
          "cookTime": 20,
          "servings": 2,
          "nutrition": {"calories": 450, "protein": 25, "carbs": 45, "fat": 15, "fiber": 8, "sodium": 300},
          "dietaryCompliance": ["AIP", "low-FODMAP"]
        }
      ],
      "totalNutrition": {"calories": 1800, "protein": 90, "carbs": 180, "fat": 60, "fiber": 30, "sodium": 1200}
    }
  ],
  "shoppingList": [
    {"item": "chicken breast", "quantity": "2 lbs", "category": "Protein", "suggestedBrands": ["Organic Valley", "Bell & Evans"]}
  ],
  "mealPrepTips": ["Tip 1", "Tip 2"],
  "dietaryNotes": ["Important note about compliance"]
}

IMPORTANT: For each item in the shopping list, include 2-3 "suggestedBrands" that are healthy, well-rated, and widely available. Choose brands known for quality, organic/natural options when applicable, and appropriate for the dietary restrictions.`;

  return prompt;
}

/**
 * Creates a user message for meal plan generation
 */
function createMealPlanUserMessage(input: MealPlanInput): string {
  const { days = 7, caloriesPerDay, mealsPerDay = 3, complexity = 'moderate', additionalInstructions, cheatMealsPerMonth = 0 } = input;

  let message = `Generate a ${days}-day meal plan with ${mealsPerDay} meals per day`;

  if (caloriesPerDay) {
    message += ` targeting approximately ${caloriesPerDay} calories per day`;
  }

  // Add complexity preference
  const complexityDescriptions = {
    quick: 'Quick & Easy (15-30 min total prep/cook time, simple recipes with minimal ingredients)',
    moderate: 'Moderate complexity (30-45 min total prep/cook time, balanced variety)',
    gourmet: 'Gourmet quality (45+ min total prep/cook time, restaurant-quality detailed recipes)',
  };
  message += `. Meal complexity: ${complexityDescriptions[complexity]}`;

  message += '.';

  // Add cheat meals if specified
  if (cheatMealsPerMonth > 0) {
    const cheatMealsPerWeek = (cheatMealsPerMonth / 4.33).toFixed(1);
    const estimatedCheatMeals = Math.max(1, Math.round((cheatMealsPerMonth / 30) * days));

    message += `\n\nCHEAT MEALS: Include ${estimatedCheatMeals} cheat meal(s) in this ${days}-day plan (based on ${cheatMealsPerMonth} cheat meals per month, approximately ${cheatMealsPerWeek} per week).

Cheat meal guidelines:
- Mark these meals with "isCheatMeal": true in the JSON
- These meals can have higher calories (20-30% more than regular meals)
- Include more indulgent ingredients like higher-fat foods, richer flavors, comfort food elements
- Still aim for some nutritional value, but allow for more enjoyable, less restrictive ingredients
- Distribute cheat meals evenly throughout the plan (not all at once)
- Examples: burgers, pizza, pasta dishes, desserts, fried foods (in moderation)
- Even cheat meals should still respect ALLERGEN restrictions but can be more flexible with dietary preferences`;
  }

  if (additionalInstructions) {
    message += `\n\nAdditional instructions: ${additionalInstructions}`;
  }

  message += '\n\nPlease ensure all meals are compliant with my dietary restrictions and provide the meal plan in the specified JSON format.';

  return message;
}

/**
 * Parses and validates the AI response
 */
function parseMealPlanResponse(content: string): MealPlanResponse {
  // Remove markdown code blocks if present
  let cleanContent = content.trim();
  if (cleanContent.startsWith('```json')) {
    cleanContent = cleanContent.replace(/```json\n?/g, '').replace(/```\n?$/g, '');
  } else if (cleanContent.startsWith('```')) {
    cleanContent = cleanContent.replace(/```\n?/g, '');
  }

  try {
    const parsed = JSON.parse(cleanContent) as MealPlanResponse;

    // Validate required fields
    if (!parsed.weeklyPlan || !Array.isArray(parsed.weeklyPlan)) {
      throw new Error('Invalid meal plan format: missing or invalid weeklyPlan array');
    }

    if (!parsed.shoppingList || !Array.isArray(parsed.shoppingList)) {
      throw new Error('Invalid meal plan format: missing or invalid shoppingList array');
    }

    // Validate each day has meals
    for (const day of parsed.weeklyPlan) {
      if (!day.meals || !Array.isArray(day.meals) || day.meals.length === 0) {
        throw new Error(`Invalid meal plan format: day ${day.day} has no meals`);
      }

      // Validate each meal has required fields
      for (const meal of day.meals) {
        if (!meal.name || !meal.type || !meal.ingredients || !meal.instructions || !meal.nutrition) {
          throw new Error(`Invalid meal format in day ${day.day}: missing required fields`);
        }
      }
    }

    return parsed;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Failed to parse meal plan JSON: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Hook for generating AI-powered meal plans with dietary restrictions
 *
 * @example
 * ```tsx
 * const generateMealPlan = useMealPlanner();
 *
 * const handleGeneratePlan = () => {
 *   generateMealPlan.mutate({
 *     dietaryProfile: {
 *       restrictions: ['AIP', 'low-FODMAP'],
 *       allergies: ['peanuts', 'shellfish'],
 *       medicalConditions: ['Hashimoto\'s thyroiditis'],
 *     },
 *     days: 7,
 *     caloriesPerDay: 2000,
 *     mealsPerDay: 3,
 *   }, {
 *     onSuccess: (mealPlan) => {
 *       console.log('Meal plan generated:', mealPlan);
 *     },
 *     onError: (error) => {
 *       console.error('Failed to generate meal plan:', error.message);
 *     },
 *   });
 * };
 * ```
 */
export function useMealPlanner(): UseMutationResult<
  MealPlanResponse,
  MealPlannerError,
  MealPlanInput
> {
  return useMutation({
    mutationFn: async (input: MealPlanInput): Promise<MealPlanResponse> => {
      // Validate input
      if (!input.dietaryProfile) {
        const error = new Error('Dietary profile is required') as MealPlannerError;
        error.code = 'INVALID_INPUT';
        throw error;
      }


      const days = input.days ?? 7;
      if (days < 1 || days > 14) {
        const error = new Error('Days must be between 1 and 14') as MealPlannerError;
        error.code = 'INVALID_INPUT';
        throw error;
      }

      // Create system and user messages
      const systemPrompt = createMealPlannerSystemPrompt(input.dietaryProfile, input.healthGoal, input.supplements);
      const userMessage = createMealPlanUserMessage(input);

      // Call OpenAI API
      const response = await createChatCompletion({
        body: {
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: systemPrompt,
            },
            {
              role: 'user',
              content: userMessage,
            },
          ],
        },
        headers: {
          'X-CREAO-API-NAME': 'OpenAIGPTChat',
          'X-CREAO-API-PATH': '/v1/ai/zWwyutGgvEGWwzSa/chat/completions',
          'X-CREAO-API-ID': '688a0b64dc79a2533460892c',
        },
      });

      // Handle API errors
      if (response.error) {
        const error = new Error(
          typeof response.error === 'object' && response.error && 'message' in response.error
            ? String(response.error.message)
            : 'Failed to generate meal plan'
        ) as MealPlannerError;
        error.code = 'API_ERROR';
        error.details = response.error;
        throw error;
      }

      // Validate response data
      if (!response.data) {
        const error = new Error('No response data received from API') as MealPlannerError;
        error.code = 'NO_DATA';
        throw error;
      }

      // Extract assistant message
      const firstChoice = response.data.choices?.[0];
      if (!firstChoice || !firstChoice.message) {
        const error = new Error('No message in API response') as MealPlannerError;
        error.code = 'INVALID_RESPONSE';
        throw error;
      }

      const content = firstChoice.message.content;
      if (!content) {
        const error = new Error('Empty message content in API response') as MealPlannerError;
        error.code = 'EMPTY_CONTENT';
        throw error;
      }

      // Parse and validate meal plan
      try {
        const mealPlan = parseMealPlanResponse(content);
        return mealPlan;
      } catch (parseError) {
        const error = new Error(
          parseError instanceof Error ? parseError.message : 'Failed to parse meal plan response'
        ) as MealPlannerError;
        error.code = 'PARSE_ERROR';
        error.details = { content, originalError: parseError };
        throw error;
      }
    },
  });
}
