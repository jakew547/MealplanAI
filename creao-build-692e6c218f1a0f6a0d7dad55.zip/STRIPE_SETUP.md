# Stripe Integration Setup Guide

This guide will help you integrate Stripe payments into your MealPlan AI application.

## Current Pricing

- **Monthly Plan**: $4.99/month
- **Yearly Plan**: $50/year (Save $10 compared to monthly)

## Setup Steps

### 1. Create a Stripe Account

1. Go to [https://stripe.com](https://stripe.com) and create an account
2. Complete the account verification process

### 2. Get Your API Keys

1. Go to [https://dashboard.stripe.com/apikeys](https://dashboard.stripe.com/apikeys)
2. You'll see two keys:
   - **Publishable key** (starts with `pk_test_` for test mode)
   - **Secret key** (starts with `sk_test_` for test mode)

### 3. Create Price IDs

1. Go to [https://dashboard.stripe.com/products](https://dashboard.stripe.com/products)
2. Click "Add product"

**For Monthly Plan:**
- Product name: "MealPlan AI Premium - Monthly"
- Description: "Unlimited AI-generated meal plans with premium features"
- Price: $4.99 USD
- Billing period: Monthly recurring
- Click "Save product"
- Copy the **Price ID** (starts with `price_`)

**For Yearly Plan:**
- Product name: "MealPlan AI Premium - Yearly"
- Description: "Unlimited AI-generated meal plans with premium features (Save $10)"
- Price: $50 USD
- Billing period: Yearly recurring
- Click "Save product"
- Copy the **Price ID** (starts with `price_`)

### 4. Configure Environment Variables

Create a `.env` file in the root of your project:

```env
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
```

### 5. Update Stripe Configuration

Edit `src/lib/stripe.ts` and replace the price IDs:

```typescript
export const PRICING = {
	monthly: {
		amount: 4.99,
		priceId: "price_YOUR_MONTHLY_PRICE_ID", // Replace with your actual Price ID
		interval: "month" as const,
		description: "$4.99/month",
	},
	yearly: {
		amount: 50,
		priceId: "price_YOUR_YEARLY_PRICE_ID", // Replace with your actual Price ID
		interval: "year" as const,
		description: "$50/year (Save $10)",
		savings: 10,
	},
};
```

### 6. Create Backend API Endpoint

You'll need to create a backend endpoint to handle Stripe Checkout Session creation. Here's an example using Node.js/Express:

```javascript
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

app.post('/api/create-checkout-session', async (req, res) => {
  const { priceId, email, successUrl, cancelUrl } = req.body;

  try {
    const session = await stripe.checkout.sessions.create({
      customer_email: email,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: successUrl,
      cancel_url: cancelUrl,
    });

    res.json({ id: session.id, url: session.url });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

### 7. Update CheckoutDialog Component

In `src/components/CheckoutDialog.tsx`, uncomment the production code:

```typescript
const handleCheckout = async () => {
  setIsProcessing(true);
  setError("");

  try {
    const plan = PRICING[selectedPlan];
    const session = await createCheckoutSession({
      priceId: plan.priceId,
      email: userEmail,
      successUrl: `${window.location.origin}?success=true`,
      cancelUrl: `${window.location.origin}?canceled=true`,
    });

    // Redirect to Stripe Checkout
    window.location.href = session.url;
  } catch (err) {
    setError(err instanceof Error ? err.message : "An error occurred during checkout");
    setIsProcessing(false);
  }
};
```

### 8. Handle Webhooks (Important!)

Set up Stripe webhooks to handle subscription events:

1. Go to [https://dashboard.stripe.com/webhooks](https://dashboard.stripe.com/webhooks)
2. Click "Add endpoint"
3. Enter your webhook URL (e.g., `https://yourdomain.com/api/webhook`)
4. Select events to listen to:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.paid`
   - `invoice.payment_failed`

Example webhook handler:

```javascript
app.post('/api/webhook', express.raw({type: 'application/json'}), async (req, res) => {
  const sig = req.headers['stripe-signature'];

  try {
    const event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );

    switch (event.type) {
      case 'checkout.session.completed':
        // Update user to premium in your database
        const session = event.data.object;
        await updateUserSubscription(session.customer_email, true);
        break;
      case 'customer.subscription.deleted':
        // Downgrade user when subscription ends
        const subscription = event.data.object;
        await updateUserSubscription(subscription.customer_email, false);
        break;
    }

    res.json({received: true});
  } catch (err) {
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
});
```

### 9. Test Your Integration

1. Use Stripe's test mode with test cards:
   - Success: `4242 4242 4242 4242`
   - Decline: `4000 0000 0000 0002`
2. Use any future expiration date and any 3-digit CVC

### 10. Go Live

1. Complete Stripe account activation
2. Switch from test keys to live keys
3. Update environment variables with live keys
4. Test thoroughly before announcing

## Current Demo Mode

The app currently runs in **demo mode** - clicking "Continue to Payment" simulates a successful payment without actually charging anything. This is perfect for testing the UI flow.

To enable real payments, follow the steps above.

## Security Notes

- Never expose your Stripe Secret Key in frontend code
- Always create Checkout Sessions on your backend
- Validate webhook signatures to prevent fraud
- Use HTTPS in production
- Store subscription status in a secure database

## Support

- Stripe Documentation: [https://stripe.com/docs](https://stripe.com/docs)
- Stripe Dashboard: [https://dashboard.stripe.com](https://dashboard.stripe.com)
- Stripe Support: Available in your dashboard

## Resources

- [Stripe Checkout Documentation](https://stripe.com/docs/payments/checkout)
- [Stripe Subscriptions Guide](https://stripe.com/docs/billing/subscriptions/overview)
- [Stripe Testing Cards](https://stripe.com/docs/testing)
