import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ChefHat, Utensils, ShoppingCart, CheckCircle2 } from "lucide-react";

interface GeneratingProgressProps {
	days: number;
}

export function GeneratingProgress({ days }: GeneratingProgressProps) {
	const [progress, setProgress] = useState(0);
	const [currentStep, setCurrentStep] = useState(0);

	// Calculate estimated time based on plan complexity
	// Base: 30 seconds, +10 seconds per day beyond 3
	const estimatedTime = 30 + Math.max(0, days - 3) * 10;

	const steps = [
		{ label: "Analyzing your goals", icon: ChefHat, time: 0.2 },
		{ label: "Selecting nutritious recipes", icon: Utensils, time: 0.5 },
		{ label: "Calculating nutrition", icon: CheckCircle2, time: 0.75 },
		{ label: "Creating grocery list", icon: ShoppingCart, time: 0.95 },
	];

	useEffect(() => {
		const interval = setInterval(() => {
			setProgress((prev) => {
				const next = prev + 100 / (estimatedTime * 10);
				if (next >= 100) {
					clearInterval(interval);
					return 100;
				}
				return next;
			});
		}, 100);

		return () => clearInterval(interval);
	}, [estimatedTime]);

	useEffect(() => {
		const step = steps.findIndex((s) => progress / 100 < s.time);
		if (step === -1) {
			setCurrentStep(steps.length - 1);
		} else {
			setCurrentStep(Math.max(0, step - 1));
		}
	}, [progress]);

	const remainingTime = Math.max(0, Math.ceil(estimatedTime * (1 - progress / 100)));

	return (
		<div className="min-h-[60vh] flex items-center justify-center">
			<Card className="w-full max-w-2xl">
				<CardContent className="p-12">
					<div className="text-center space-y-8">
						{/* Animated Icon */}
						<motion.div
							className="w-24 h-24 mx-auto bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center shadow-2xl"
							animate={{
								scale: [1, 1.1, 1],
								rotate: [0, 5, -5, 0],
							}}
							transition={{
								duration: 2,
								repeat: Infinity,
								ease: "easeInOut",
							}}
						>
							<ChefHat className="w-12 h-12 text-white" />
						</motion.div>

						{/* Title */}
						<div>
							<h2 className="text-3xl font-bold mb-2">Creating Your Meal Plan</h2>
							<p className="text-gray-600">
								Estimated time remaining: <span className="font-semibold text-primary">{remainingTime}s</span>
							</p>
						</div>

						{/* Progress Bar */}
						<div className="space-y-2">
							<Progress value={progress} className="h-3" />
							<p className="text-sm text-gray-500">{Math.round(progress)}% complete</p>
						</div>

						{/* Steps */}
						<div className="space-y-4">
							{steps.map((step, index) => {
								const Icon = step.icon;
								const isComplete = index < currentStep;
								const isCurrent = index === currentStep;

								return (
									<motion.div
										key={index}
										initial={{ opacity: 0, x: -20 }}
										animate={{ opacity: 1, x: 0 }}
										transition={{ delay: index * 0.1 }}
										className={`flex items-center gap-4 p-4 rounded-lg transition-all ${
											isCurrent
												? "bg-primary/10 border-2 border-primary"
												: isComplete
												? "bg-green-50 border-2 border-green-300"
												: "bg-gray-50 border-2 border-transparent"
										}`}
									>
										<div
											className={`w-12 h-12 rounded-full flex items-center justify-center ${
												isCurrent
													? "bg-primary"
													: isComplete
													? "bg-green-500"
													: "bg-gray-300"
											}`}
										>
											<Icon
												className={`w-6 h-6 ${
													isCurrent || isComplete ? "text-white" : "text-gray-500"
												}`}
											/>
										</div>
										<div className="flex-1 text-left">
											<p
												className={`font-semibold ${
													isCurrent ? "text-primary" : isComplete ? "text-green-700" : "text-gray-500"
												}`}
											>
												{step.label}
											</p>
										</div>
										{isComplete && (
											<motion.div
												initial={{ scale: 0 }}
												animate={{ scale: 1 }}
												transition={{ type: "spring", stiffness: 500, damping: 15 }}
											>
												<CheckCircle2 className="w-6 h-6 text-green-500" />
											</motion.div>
										)}
									</motion.div>
								);
							})}
						</div>

						{/* Fun Fact */}
						<motion.div
							initial={{ opacity: 0 }}
							animate={{ opacity: 1 }}
							transition={{ delay: 1 }}
							className="mt-8 p-4 bg-blue-50 rounded-lg"
						>
							<p className="text-sm text-blue-900">
								<span className="font-semibold">Did you know?</span> A well-planned meal prep can save you up to
								10 hours per week and significantly reduce food waste!
							</p>
						</motion.div>
					</div>
				</CardContent>
			</Card>
		</div>
	);
}
