import { createFileRoute } from "@tanstack/react-router";
import { MealPlannerApp } from "@/components/MealPlannerApp";

export const Route = createFileRoute("/")({
	component: App,
});

function App() {
	return <MealPlannerApp />;
}
