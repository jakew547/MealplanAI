import { loadStripe, type Stripe } from "@stripe/stripe-js";

// IMPORTANT: Replace this with your actual Stripe publishable key
// Get your key from: https://dashboard.stripe.com/apikeys
export const STRIPE_PUBLISHABLE_KEY = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || "pk_test_YOUR_PUBLISHABLE_KEY_HERE";

// Pricing configuration
export const PRICING = {
	monthly: {
		amount: 4.99,
		priceId: "price_monthly", // Replace with your actual Stripe Price ID
		interval: "month" as const,
		description: "$4.99/month",
	},
	yearly: {
		amount: 50,
		priceId: "price_yearly", // Replace with your actual Stripe Price ID
		interval: "year" as const,
		description: "$50/year (Save $10)",
		savings: 10,
	},
};

let stripePromise: Promise<Stripe | null>;

export const getStripe = () => {
	if (!stripePromise) {
		stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);
	}
	return stripePromise;
};

export interface CheckoutSessionData {
	priceId: string;
	email: string;
	successUrl: string;
	cancelUrl: string;
}

// This function would be called from your backend
// For now, it's a placeholder showing the data structure
export async function createCheckoutSession(data: CheckoutSessionData) {
	// In production, this should call your backend API endpoint
	// Your backend should create a Stripe Checkout Session using the Stripe API
	// Example backend endpoint: POST /api/create-checkout-session

	const response = await fetch("/api/create-checkout-session", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify(data),
	});

	if (!response.ok) {
		throw new Error("Failed to create checkout session");
	}

	const session = await response.json();
	return session;
}
