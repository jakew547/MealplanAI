import { useState } from "react";
import { MealPlanWizard } from "@/components/MealPlanWizard";
import { GeneratingProgress } from "@/components/GeneratingProgress";
import { MealPlanView } from "@/components/MealPlanView";
import { MealPlanHistory } from "@/components/MealPlanHistory";
import { SubscriptionBanner } from "@/components/SubscriptionBanner";
import { AuthDialog } from "@/components/AuthDialog";
import { CheckoutDialog } from "@/components/CheckoutDialog";
import { useMealPlanner, type DietaryProfile, type MealPlanResponse, type HealthGoal, type SupplementTarget } from "@/hooks/use-meal-planner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChefHat, History, Eye, User } from "lucide-react";

interface SavedMealPlan {
	id: string;
	profile: DietaryProfile;
	healthGoal?: HealthGoal;
	supplements?: SupplementTarget[];
	plan: MealPlanResponse;
	createdAt: string;
}

interface UserData {
	email: string;
	isPremium: boolean;
	subscriptionEnd?: string;
}

export function MealPlannerApp() {
	const [currentProfile, setCurrentProfile] = useState<DietaryProfile | null>(null);
	const [currentHealthGoal, setCurrentHealthGoal] = useState<HealthGoal | null>(null);
	const [currentSupplements, setCurrentSupplements] = useState<SupplementTarget[]>([]);
	const [currentPlanOptions, setCurrentPlanOptions] = useState<{ days: number; mealsPerDay: number } | null>(null);
	const [currentPlan, setCurrentPlan] = useState<MealPlanResponse | null>(null);
	const [savedPlans, setSavedPlans] = useState<SavedMealPlan[]>(() => {
		const saved = localStorage.getItem("mealPlans");
		return saved ? JSON.parse(saved) : [];
	});
	const [user, setUser] = useState<UserData | null>(() => {
		const savedUser = localStorage.getItem("user");
		return savedUser ? JSON.parse(savedUser) : null;
	});
	const [showAuthDialog, setShowAuthDialog] = useState(false);
	const [showCheckoutDialog, setShowCheckoutDialog] = useState(false);
	const [checkoutEmail, setCheckoutEmail] = useState("");
	const [activeTab, setActiveTab] = useState("create");

	const generateMealPlan = useMealPlanner();

	const handleGeneratePlan = (
		profile: DietaryProfile,
		healthGoal: HealthGoal,
		supplements: SupplementTarget[],
		options: { days: number; caloriesPerDay?: number; mealsPerDay: number; complexity?: "quick" | "moderate" | "gourmet"; additionalInstructions?: string; cheatMealsPerMonth?: number }
	) => {
		// Free users can generate 1 plan, then must upgrade
		if (!user) {
			setShowAuthDialog(true);
			return;
		}

		if (!user.isPremium && savedPlans.length >= 1) {
			// Free user has already generated 1 plan, show upgrade dialog
			setCheckoutEmail(user.email);
			setShowCheckoutDialog(true);
			return;
		}

		setCurrentProfile(profile);
		setCurrentHealthGoal(healthGoal);
		setCurrentSupplements(supplements);
		setCurrentPlanOptions({ days: options.days, mealsPerDay: options.mealsPerDay });

		generateMealPlan.mutate(
			{
				dietaryProfile: profile,
				healthGoal,
				supplements,
				...options,
			},
			{
				onSuccess: (plan) => {
					setCurrentPlan(plan);

					// Save to history
					const newPlan: SavedMealPlan = {
						id: Date.now().toString(),
						profile,
						healthGoal,
						supplements,
						plan,
						createdAt: new Date().toISOString(),
					};
					const updatedPlans = [newPlan, ...savedPlans];
					setSavedPlans(updatedPlans);
					localStorage.setItem("mealPlans", JSON.stringify(updatedPlans));

					setActiveTab("view");
				},
			}
		);
	};

	const handleRegenerateMeal = (dayIndex: number, mealIndex: number) => {
		if (!user || !currentProfile || !currentPlan || !currentHealthGoal) return;

		// Free users must upgrade to regenerate meals
		if (!user.isPremium) {
			setCheckoutEmail(user.email);
			setShowCheckoutDialog(true);
			return;
		}

		// Generate a single meal replacement
		generateMealPlan.mutate(
			{
				dietaryProfile: currentProfile,
				healthGoal: currentHealthGoal,
				supplements: currentSupplements,
				days: 1,
				mealsPerDay: 1,
				additionalInstructions: `Generate a ${currentPlan.weeklyPlan[dayIndex].meals[mealIndex].type} meal different from "${currentPlan.weeklyPlan[dayIndex].meals[mealIndex].name}"`,
			},
			{
				onSuccess: (newPlan) => {
					if (newPlan.weeklyPlan[0]?.meals[0]) {
						const updatedPlan = { ...currentPlan };
						updatedPlan.weeklyPlan[dayIndex].meals[mealIndex] = newPlan.weeklyPlan[0].meals[0];
						setCurrentPlan(updatedPlan);
					}
				},
			}
		);
	};

	const handleLoadPlan = (plan: SavedMealPlan) => {
		setCurrentProfile(plan.profile);
		setCurrentPlan(plan.plan);
		setActiveTab("view");
	};

	const handleDeletePlan = (id: string) => {
		const updatedPlans = savedPlans.filter(p => p.id !== id);
		setSavedPlans(updatedPlans);
		localStorage.setItem("mealPlans", JSON.stringify(updatedPlans));
	};

	const handleLogin = (email: string, isPremium: boolean) => {
		const userData: UserData = {
			email,
			isPremium,
			subscriptionEnd: isPremium ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : undefined,
		};
		setUser(userData);
		localStorage.setItem("user", JSON.stringify(userData));
		setShowAuthDialog(false);
	};

	const handleLogout = () => {
		setUser(null);
		localStorage.removeItem("user");
		setCurrentPlan(null);
		setCurrentProfile(null);
	};

	const handleUpgradeClick = (email: string) => {
		setCheckoutEmail(email);
		setShowCheckoutDialog(true);
	};

	const handleCheckoutSuccess = (interval: "month" | "year") => {
		if (user) {
			const daysToAdd = interval === "month" ? 30 : 365;
			const upgradedUser = {
				...user,
				isPremium: true,
				subscriptionEnd: new Date(Date.now() + daysToAdd * 24 * 60 * 60 * 1000).toISOString(),
			};
			setUser(upgradedUser);
			localStorage.setItem("user", JSON.stringify(upgradedUser));
		} else if (checkoutEmail) {
			// User wasn't logged in, create account with premium
			const daysToAdd = interval === "month" ? 30 : 365;
			const newUser: UserData = {
				email: checkoutEmail,
				isPremium: true,
				subscriptionEnd: new Date(Date.now() + daysToAdd * 24 * 60 * 60 * 1000).toISOString(),
			};
			setUser(newUser);
			localStorage.setItem("user", JSON.stringify(newUser));
		}
	};

	const handleBannerUpgrade = () => {
		if (user) {
			setCheckoutEmail(user.email);
			setShowCheckoutDialog(true);
		}
	};

	return (
		<div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
			<div className="container mx-auto px-4 py-8 max-w-7xl">
				{/* Header */}
				<div className="flex items-center justify-between mb-8">
					<div className="flex items-center gap-3">
						<div className="bg-gradient-to-br from-green-500 to-emerald-600 p-3 rounded-xl shadow-lg">
							<ChefHat className="w-8 h-8 text-white" />
						</div>
						<div>
							<h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
								MealPlan AI
							</h1>
							<p className="text-gray-600 text-sm">Personalized meal plans for every health goal</p>
						</div>
					</div>
					<div className="flex items-center gap-4">
						{user ? (
							<div className="flex items-center gap-3">
								<div className="text-right">
									<p className="text-sm font-medium">{user.email}</p>
									<p className="text-xs text-gray-500">
										{user.isPremium ? "Premium Member" : "Free Account"}
									</p>
								</div>
								<Button variant="outline" size="sm" onClick={handleLogout}>
									Logout
								</Button>
							</div>
						) : (
							<Button onClick={() => setShowAuthDialog(true)}>
								<User className="w-4 h-4 mr-2" />
								Sign In
							</Button>
						)}
					</div>
				</div>

				{/* Subscription Banner */}
				{user && !user.isPremium && (
					<SubscriptionBanner onUpgrade={handleBannerUpgrade} />
				)}

				{/* Main Content */}
				{user ? (
					<Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
						<TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
							<TabsTrigger value="create" className="flex items-center gap-2">
								<ChefHat className="w-4 h-4" />
								Create Plan
							</TabsTrigger>
							<TabsTrigger value="view" className="flex items-center gap-2" disabled={!currentPlan}>
								<Eye className="w-4 h-4" />
								View Plan
							</TabsTrigger>
							<TabsTrigger value="history" className="flex items-center gap-2">
								<History className="w-4 h-4" />
								History
							</TabsTrigger>
						</TabsList>

						<TabsContent value="create" className="space-y-6">
							{generateMealPlan.isPending && currentPlanOptions ? (
								<GeneratingProgress days={currentPlanOptions.days} />
							) : (
								<MealPlanWizard onComplete={handleGeneratePlan} isGenerating={generateMealPlan.isPending} />
							)}
						</TabsContent>

						<TabsContent value="view" className="space-y-6">
							{currentPlan && currentProfile ? (
								<MealPlanView
									plan={currentPlan}
									profile={currentProfile}
									onRegenerateMeal={handleRegenerateMeal}
									isRegenerating={generateMealPlan.isPending}
								/>
							) : (
								<Card>
									<CardContent className="p-12 text-center">
										<p className="text-gray-500">No meal plan generated yet. Go to Create Plan to get started.</p>
									</CardContent>
								</Card>
							)}
						</TabsContent>

						<TabsContent value="history" className="space-y-6">
							<MealPlanHistory
								plans={savedPlans}
								onLoadPlan={handleLoadPlan}
								onDeletePlan={handleDeletePlan}
							/>
						</TabsContent>
					</Tabs>
				) : (
					<Card className="max-w-2xl mx-auto mt-12">
						<CardHeader className="text-center">
							<CardTitle className="text-2xl">Welcome to MealPlan AI</CardTitle>
							<CardDescription className="text-base">
								Create personalized meal plans tailored to your health goals and dietary needs
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-6">
							<div className="grid gap-4">
								<div className="flex items-start gap-3">
									<div className="bg-green-100 p-2 rounded-lg">
										<ChefHat className="w-5 h-5 text-green-600" />
									</div>
									<div>
										<h3 className="font-semibold">AI-Powered Meal Planning</h3>
										<p className="text-sm text-gray-600">Generate weekly meal plans tailored to your specific dietary needs</p>
									</div>
								</div>
								<div className="flex items-start gap-3">
									<div className="bg-blue-100 p-2 rounded-lg">
										<Eye className="w-5 h-5 text-blue-600" />
									</div>
									<div>
										<h3 className="font-semibold">Goal-Based Planning</h3>
										<p className="text-sm text-gray-600">Customized plans for weight loss, muscle gain, heart health, and more</p>
									</div>
								</div>
								<div className="flex items-start gap-3">
									<div className="bg-purple-100 p-2 rounded-lg">
										<History className="w-5 h-5 text-purple-600" />
									</div>
									<div>
										<h3 className="font-semibold">Integrated Grocery Lists</h3>
										<p className="text-sm text-gray-600">Automatic shopping lists organized by category with aggregated quantities</p>
									</div>
								</div>
							</div>
							<Button onClick={() => setShowAuthDialog(true)} className="w-full" size="lg">
								Get Started
							</Button>
						</CardContent>
					</Card>
				)}

				{/* Auth Dialog */}
				<AuthDialog
					open={showAuthDialog}
					onClose={() => setShowAuthDialog(false)}
					onLogin={handleLogin}
					onUpgradeClick={handleUpgradeClick}
				/>

				{/* Checkout Dialog */}
				<CheckoutDialog
					open={showCheckoutDialog}
					onClose={() => setShowCheckoutDialog(false)}
					userEmail={checkoutEmail}
					onSuccess={handleCheckoutSuccess}
				/>
			</div>
		</div>
	);
}
