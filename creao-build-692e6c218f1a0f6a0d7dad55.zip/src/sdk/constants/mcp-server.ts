export type McpServerId = keyof typeof MCP_SERVERS;

// { "mcp-id": { id: string, name: string, url: string } }
export const MCP_SERVERS = {
  "686de33a6fd1cae1afbb55b4": {
    "id": "686de33a6fd1cae1afbb55b4",
    "name": "GoogleDocs",
    "url": "https://backend.composio.dev/v3/mcp/ec0e99e9-94b9-49dd-b136-a8a062279c21/mcp?user_id=692e527d8785b71792f71836"
  }
};